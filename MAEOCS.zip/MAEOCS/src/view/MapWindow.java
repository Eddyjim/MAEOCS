package view;

import java.awt.Dimension;
import java.io.IOException;

import javax.swing.JFrame;

import com.sun.corba.se.impl.encoding.CodeSetConversion.BTCConverter;

import model.Node;

/**
 * This class is used to show a new window that will contain the map to edit
 * @author Carlos Gait�n Mora && Edward Jim�nez Mart�nez
 */
@SuppressWarnings("serial")
public class MapWindow extends JFrame{
	
	private MapPanel map;
	private Dimension mapDimension;
	private DimensionsWindow dimensionWindow;
	
	
	public MapWindow(State state, LocalAtributesManager selectedNode) {
		 setLocation(Theme.mapWindowLocation);
	     getContentPane().setBackground(Theme.background);
	     setForeground(Theme.foreground);
	     setBackground(Theme.background);
	     getContentPane().setBackground(Theme.background);
	     map = new MapPanel(state,selectedNode);
	     this.add(map);
	     setEnabled(true);
	     setVisible(true);
	     
	}
	
	public MapWindow(State selectedState, LocalAtributesManager selectedNode,
		String saveFile) throws IOException, ClassNotFoundException {
		setLocation(Theme.mapWindowLocation);
		getContentPane().setBackground(Theme.background);
		setForeground(Theme.foreground);
		setBackground(Theme.background);
	    getContentPane().setBackground(Theme.background);
	    map = new MapPanel(selectedState,selectedNode, saveFile);
	    this.add(map);
	    setEnabled(true);
	    setVisible(true);
	}

	public void newSize(int width, int height, int gridSize){
		 
	    map.resize(width,height, gridSize);
	    
	    mapDimension = new Dimension (width+gridSize,height+gridSize);
	    setSize(mapDimension);
	    setResizable(false);
	    setEnabled(true);
	    
	}
	
	public void setDimensionWindow(DimensionsWindow dimensionWindow){
		this.dimensionWindow = dimensionWindow;
	}
	
	public void resize(){
		dimensionWindow.beVisible();
	}

	public void setBackgroundImage(String imgFile2) {
		
		map.setBackground(imgFile2);
		
	}

	public void compileMap() {
		map.compileMap();
	}

	public void startSimulation() {
		map.startSimulation();
	}

	public void saveFile(String saveFile) throws IOException {
		map.saveMap(saveFile);
		
	}

	public void exportFile(String saveFile) throws IOException {
		map.exportMap(saveFile);
		
	}
}
